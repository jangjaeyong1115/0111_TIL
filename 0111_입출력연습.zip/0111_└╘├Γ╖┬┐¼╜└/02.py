import sys
sys.stdin = open("input2.txt","r")
for i in input().split():
    print(i,end=" ")
print()
