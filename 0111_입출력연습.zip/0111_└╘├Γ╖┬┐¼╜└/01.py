import sys
sys.stdin = open("input1.txt","r")
print(input(),end=" ")
print()
