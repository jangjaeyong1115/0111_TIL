number = list(input())
number = list(map(int,number))

n = sum(number)
print(n)