sum = 0
for i in range(1,int(input())+ 1):
    sum += i
print(sum)